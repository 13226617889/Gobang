package 五子棋.test1;

import java.util.ArrayList;
/**
 * 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 1 1 0 0 0 0 0 
0 0 0 0 0 0 0 0 1 1 2 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 2 2 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 2 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 1 1 2 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 2 0 2 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 2 0 1 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
 *
 */
public class Demo {
	private static ArrayList<ArrayList<Integer>> list2 = new ArrayList<>();
	public static void main(String[] args) {
		int b = 0;
		while(b < 5) {
			if(b == 3 ) {
				b--;
			}
			b++;
		}
	}
	public static void add(int n) {
		ArrayList<Integer> list = new ArrayList<>();
		list.add(n + 1);
		list.add(n + 2);
		list2.add(list);
	}
}
