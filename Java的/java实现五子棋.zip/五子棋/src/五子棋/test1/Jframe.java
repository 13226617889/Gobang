package 五子棋.test1;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.*;
public class Jframe extends JFrame{
	private static int WIDTH = 800;
	private static int HEIGHT = 700;
	public Jframe() {
		this.setTitle("多个画板窗口测试");
		this.setSize(WIDTH, HEIGHT);
		this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
		JPanel contentPane = new JPanel();
		
		this.setContentPane(contentPane);
		this.setLayout(new BorderLayout());
		Test1 m1 = new Test1();
		mypenal2 m2 = new mypenal2();
		m1.setPreferredSize(new Dimension(700,700));
		contentPane.add(m1,"West");
		contentPane.add(m2,"East");
		m2.setPreferredSize(new Dimension(95,700));
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension screenSize = tk.getScreenSize();
		int x = (screenSize.width - WIDTH) / 2;
		int y = (screenSize.height - HEIGHT) / 2;
		this.setLocation(x,y);
		this.setResizable(false);
		this.addMouseListener(m1);
		this.addMouseMotionListener(m1);
		this.addKeyListener(m1);
		this.setVisible(true);
	}
	public static void main(String[] args) {
		new Jframe();
	}
}
