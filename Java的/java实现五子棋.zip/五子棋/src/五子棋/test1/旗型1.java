package 五子棋.test1;

public class 旗型1 {
	public static void main(String[] args) {
		int[][] board = new int[16][16];
		//board[4][2] = 1;
		//board[4][4] = 1;
		board[8][3] = 1;
		board[9][4] = 1;
		board[9][2] = 1;
		board[10][3] = 1;
		board[6][3] = 2;
		///board[6][4] = 1;
		//board[6][5] = 1;
		//board[4][0] = 1;
		for (int[] is : board) {
			for(int is2 : is) {
				System.out.print(is2 + " ");
			}
			System.out.println();
		}
		int x = 1;
		int y = 3;
		int[][] xi = new int[][] {{7,3}};
		int y1 = 0;
		int y2 = 0;
		int y3 = 0;
		int y4 = 0;
//		for(int i=0;i<board.length;i++) {
//			for(int j=0;j<board[i].length;j++) {
//				int c = flag(board,i,j);
//				if(c == 1) {
//					y1++;
//				}else if(c == 2) {
//					y2++;
//				}else if(c == 3) {
//					y3++;
//				}else if(c == 4) {
//					y4++;
//				}
//			}
//		}
//		if(y1 != 0) {
//			System.out.println("winGood");
//		}else if(y2 != 0) {
//			System.out.println("1");
//		}else if(y3 != 0) {
//			System.out.println("优先级2");
//		}
//		
		//int c = flag(board,9,3);
		int c1 = flag(board,9,3);
	} 
	public static boolean isOnBoard(int x, int y) {
		return (x < 16 && x >= 0) && (y<16 && y>=0);
	}
	/**
	 * 先拿到每一行的值
	 * 再计算碰到空格的  和碰到玩家的棋子另外存储
	 * 
	 * @param board
	 * @param x
	 * @param y
	 */
	public static int flag(int[][] board,int x, int y) {
		int[][] direction = new int [][]{{0,1},{1,0},{1,1},
			{-1,1}};
		int count = 0;
		int count2 = 0;
		int count3 = 0;
		int you1 = 0;
		int you2 = 0;
		int you3 = 0;
		for (int[] is : direction) {
			boolean bl = false;
			boolean db = false;
			int X = x;
			int Y = y;
			int a = 0;
			int b = 0;
			int spackcount = 0;
			X += -is[0];
			Y += -is[1];
			if(isOnBoard(X, Y) && board[X][Y] == 0) {
				spackcount++;
				X += -is[0];
				Y += -is[1];
			}
			while(isOnBoard(X, Y) && board[X][Y] == 1 && spackcount<=1){
				a++;
				X += -is[0];
				Y += -is[1];
				if(a >= 4 && spackcount == 1 ) { 
					System.out.println("win");
					return 1;
				}
				if(isOnBoard(X, Y) && board[X][Y] == 0) {
					X = x;
					Y = y;
					X += is[0];
					Y += is[1];
					if(isOnBoard(X, Y) && a==2 && board[X][Y] == 0) {
						you2++;
						System.out.println(102);
					}
					while(isOnBoard(X, Y) && board[X][Y] == 1) {
						a++;
						X += is[0];
						Y += is[1];
						if(isOnBoard(X, Y) && board[X][Y] == 0) {
							if(a == 2) {
								you2++;
							}else if(a == 3 && spackcount == 0) {
								you1++;
							}else if(a == 3 && spackcount != 0) {
								you2++;
								System.out.println(1231236);
							}
							else if(a >= 4) {
								System.out.println("赢了81");
								return 1;
							}else if(a == 2 && spackcount == 1) {
								you2++;
							}
						}else if(isOnBoard(X, Y) && board[X][Y] == 2) {
							if(a == 3) {
								count3++;
							}else if(a > 3) {
								System.out.println("win89");
								return 1;
							}
						}
					}
				}else if(isOnBoard(X, Y) && a >= 2 && board[X][Y] == 2) {
					db = true;
					b = a;
				}else if(isOnBoard(X, Y) && a == 1 && board[X][Y] == 2) {
					X = x;
					Y = y;
					X += is[0];
					Y += is[1];
					while(isOnBoard(X, Y) && board[X][Y] == 1){
						a++;
						X += is[0];
						Y += is[1];
						if(isOnBoard(X, Y) && a >= 4 && board[X][Y] == 0) {
							return 1;
						}
					}
				}
				else if(isOnBoard(X, Y) && a==1 && board[X][Y] == 0) {
					you3++;
				}else if(!isOnBoard(X, Y)) {
					X = x;
					Y = y;
					X += is[0];
					Y += is[1];
					while(isOnBoard(X, Y) && board[X][Y] == 1) {
						a++;
						X += is[0];
						Y += is[1];
						if(a >= 4) {
							System.out.println("winwin");
							return 1;
						}
					}
				}
			}
			a = 0;
			if(db) {
				X = x;
				Y = y;
				X += is[0];
				Y += is[1];
				while(isOnBoard(X, Y) && board[X][Y] == 1){
					a++;
					X += is[0];
					Y += is[1];
					if(a + b >= 4) {
						System.out.println("win163");
						return 1;
					}
					if(isOnBoard(X, Y) && a >= 2 && board[X][Y] == 0) {
						System.out.println("win122");
						return 1;
					}else if(isOnBoard(X, Y) && a == 1 && board[X][Y] == 0) {
						count3++;
						System.out.println("123 count3");
					}
					else if(isOnBoard(X, Y) && a >= 2 && board[X][Y] == 2) {
						System.out.println("130win5卡1");
						return 1;
					}
				}
			}
			a = 0;
			X = x;
			Y = y;
			X += -is[0];
			Y += -is[1];
			if(isOnBoard(X, Y) && board[X][Y] == 0) {
				X = x;
				Y = y;
				X += is[0];
				Y += is[1];
				while(isOnBoard(X, Y) && board[X][Y] == 1) {
					a++;
					X += is[0];
					Y += is[1];
					System.out.println(a);
					if(isOnBoard(X, Y) && a >=4) {
						System.out.println("我赢了宝贝");
						return 1;
					}
					if(isOnBoard(X, Y) && a >=3 && board[X][Y] == 2) {
						count3++;
						System.out.println(333);
					}else if(isOnBoard(X, Y) && a >= 3 && board[X][Y] == 0) {
						you1++;
					}else if(isOnBoard(X, Y) && a >= 2 && board[X][Y] == 0) {
						you2++;
						System.out.println(5533);
					}else if(isOnBoard(X, Y) && a==1 && board[X][Y] == 0) {
						you3++;
					}
				}
			}
			
			//a = 0;
			//如果count3不等于则只能判定一样的。或者
			/*if(bl && count3 == 0) {
				System.out.println("进入双空条件");
				X = x;
				Y = y;
				X += is[0];
				Y += is[1];
				while(isOnBoard(X , Y) && board[X][Y] == 1) {
					a++;
					X += is[0];
					Y += is[1];
					if(isOnBoard(X , Y) && board[X][Y] == 0) {
						count += a;
						bl = false; 
						count2++;	// 到了这里就证明两边结尾都有空格
					}
					if(isOnBoard(X , Y) && count == 3 && board[X][Y] == 0) {
						System.out.println("优先级为1");
						System.out.println("棋形为：0 1 1 0 1 0 ");
					}
				}
			}*/
			/*if(isOnBoard(X , Y) && bl && count + a == 4) {
				System.out.println("优先级为Win");
				System.out.println("棋形为：0 1 1 0 1 1 ");
			}
			if(count2 == 2) {
				System.out.println("优先级为1");
				System.out.println("棋形为：0 0 0 0 0 0");
				System.out.println("棋形为：0 0 0 1 0 0");
				System.out.println("棋形为：0 0 1 0 1 0");
				System.out.println("棋形为：0 0 0 1 0 0");
				System.out.println("棋形为：0 0 0 0 0 0");
				count2 = 0;
			}
			count = 0;*/
		}
		if(you1 >= 1) {
			System.out.println("优先级为2");
			System.out.println("棋形为：0 1 1 0 1 0 ");
			System.out.println(count3);
			//return 2;
		}
		if(count3 >= 2 || count3 == 1 && you2 == 1) {
			System.out.println("count3 >= 2优先级2");
			count3 = 0;
			//return 2;
		}
		if(you2 >= 2) {
			System.out.println("you2 >= 2 优先级2");
			you2 = 0;
			return 2;
		}
		if(you2 == 1) {
			return 3;
		}
		if(you3 >= 1) {
			return 4;
		}
		return -1;
	}

	
	/**
	 * 先拿到每一行的值
	 * 再计算碰到空格的  和碰到玩家的棋子另外存储
	 */
	public static void flag2(int[][] board,int x, int y) {
		int[][] direction = new int [][]{{0,1},{1,0},{1,1},
			{-1,1}};
		int count = 0; //存储碰到当前行的
		int count2 = 0;//存储碰到玩家的棋子的
		int count3 = 0;//存储两边都是空格的
		for (int[] is : direction) {
			int X = x;int Y = y;int a = 0;int b = 0;
			X += -is[0];
			Y += -is[1];
			if(isOnBoard(X, Y) && board[X][Y] == 1) {
				while(isOnBoard(X, Y)){
					a++;
					X += -is[0];
					Y += -is[1];
					if(isOnBoard(X, Y) && board[X][Y] == 0) {
						X = x;
						Y = y;
						X += is[0];
						Y += is[1];
						while(isOnBoard(X, Y) && board[X][Y] == 1){
							if(isOnBoard(X, Y) && a >= 2 && board[X][Y] == 0) {
								System.out.println("优先级为1");
								System.out.println("棋形为：0 1 1 0 1 0 ");
							}else if(isOnBoard(X, Y) && a >= 2 && board[X][Y] == 2)
							
						}
					}
				}
			}else if(isOnBoard(X, Y) && board[X][Y] == 0) {
				
			}else {
				
			}
			
		}
	}
}

