package 窗口测试;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class mypanel extends JPanel{
	private static BufferedImage bg;
	static {
		try {
			bg =  ImageIO.read(new File("image\\background.jpg"));
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	
	}
	public void paint(Graphics g) {
		super.paint(g);
		g.drawImage(bg,-80, -130, 850, 850, null);
	}
}
