package 窗口测试;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.*;
public class Jframe extends JFrame{
	private static int WIDTH = 800;
	private static int HEIGHT = 700;
	public Jframe() {
		this.setTitle("多个画板窗口测试");
		this.setSize(WIDTH, HEIGHT);
		this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
		JPanel contentPane = new JPanel();
		
		this.setContentPane(contentPane);
		this.setLayout(new BorderLayout());
		mypanel m1 = new mypanel();
		mypenal2 m2 = new mypenal2();
		m1.setPreferredSize(new Dimension(700,700));
		contentPane.add(m1,"West");
		contentPane.add(m2,"East");
		m2.setPreferredSize(new Dimension(85,700));
		this.setVisible(true);
	}
	public static void main(String[] args) {
		new Jframe();
	}
}
